//9/16/2025
//ncruz

public class Chef {
    public void makeChicken() {
        System.out.println("The Chef makes Chicken");
    }

    public void makeSalad() {
        System.out.println("The Chef makes Salad");
    }

    public void makeSpecialDish() {
        System.out.println("The Chef makes bbq ribs");
    }
}