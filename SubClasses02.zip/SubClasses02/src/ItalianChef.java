public class ItalianChef {
    public void makeChicken() {
        System.out.println("The Chef makes Chicken");
    }

    public void makeSalad() {
        System.out.println("The Chef makes Salad");
    }

    public void makeSpecialDish() {
        System.out.println("The Chef makes eggplant parm");
    }

    }

