public class ChineseChef  extends Chef {
    public void makeFriedRice() {
        System.out.println("The Chef makes Fried Rice");
    }
}
